Handheld CNC Router Baseplate - Cameron Chaney

Material: 1/4" Aluminum (from Jacobs stock)

Units: mm

Dimensions: 250mm x 360mm

I've shrunk the hole sizes down slightly so that I can drill them out more precisely after waterjetting. 